### Server API Urls

List of root API routes:

  * User
  * Locker

All of return data from the server consists of

* `data`
  * It houses all data processed by the server based on the query.
* `success` 
  * Indicates whether the query is success or fail.
  * `true`
    * includes the `data` on the return payload
  * `false`
    * includes `error_code` & `error_msg`

`error_code`'s
*  `00` - search item not found
*  `01` - Parameter required
*  `02` - Query execution error
*  `03` - Parameter format/value error
*  `04` - API message


# User

Path: `/user`  
List of `user` APIs:

* Sign in
* Sign out
* User profile look-up
* Rental information 

___

## User Lists

Method: `GET`  
Path: `/list`

Fetches a paginated list of users and their basic profile.

Payload: 

* `page_cursor`: page index
  * if N/A, defaults to `1`
* `page_size`: size of the page to return
  * if N/A, defaults to returning all data

Returns:

* Array of users with their basic profile:
    * `first_name`
    * `last_name`
    * `student_id_num`
    * `user_id`

___

## Sign in

Method: `GET`  
Path: `/sign-in`

Authenticates user logon session on Web and Mobile app.

Payload: 

  * `student_id`: Student ID of the student
    * 7 numeric digits
  * `password`: Password of the student
    * Alphanumeric characters
    * minimum of 6 characters

Returns:

JWT Token: _soon_

___

## Sign out

Method: `POST`  
Path: `/sign-out`

Logs the user out of a session from either Web or Mobile app.

Payload: 
* N/A

___

## User profile look-up

Method: `GET`  
Path: `/profile`

Fetch a user's personal profile.

Payload: 

  * Either one of the f.f. but _not both_:
    * `user_id`: User ID of the student
    * `student_id`: Student ID of the student
      * 7 numeric digits
  * Auth token. _Soon_.

Returns:  

  * `first_name` 
  * `last_name`
  * `id_num`
  * `gender`
  * `email_addr`
  * `course_section`

___

## Rental information

Method: `GET`  
Path: `/rental-info`

Fetch a user's or unit's rental information.

Payload: 

  * Either of the f.f. but _not both_:
    * `user_id`: User ID of the student
    * `unit_id`: Unit ID of the unit
  * Auth token. _Soon_.

Returns:  

  * `start_time` 
  * `end_time`
  * `mode`
  * `duration`
  * `unit_id`
  * `amount`
  * `user_id`

___

## D.O. List

Method: `GET`  
Path: `/do/list`

Fetch a list of Discipline Officer's with their basic profile.

Payload: 
* N/A

Returns:  
* Array of users with their basic profile:
  * `first_name` 
  * `last_name`
  * `id_num`
  * `officer_id`
 
___

## D.O. Profile

Method: `GET`  
Path: `/do/profile`

Fetch a Discipline Officer's basic profile.

Payload: 
* `officer_id`: User ID of the officer

Returns:  
* Array of users with their basic profile:
  * `first_name` 
  * `last_name`
  * `id_num`
  * `officer_id`
 
___

# Locker

Path: `/locker`
List of APIs:

  * Unit list
  * Area list
  * Locker availability
  * Acquire locker unit

---

## Unit list

Method: `GET`  
Path: `/unit-list`

Fetch paginated locker units list.

Payload: 

  * `area_id`: ID of the Locker area.
  * Auth token. _Soon_.

Returns:  
* Array of units with their basic profile:
  * `unit_id`
  * `unit_area`: May be deprecated soon.
  * `unit_status`
  * `user_id`: May be deprecated soon.

---
## Area list

Method: `GET`  
Path: `/area-list`

Fetch paginated area list.

Payload: 
* _N/A_
* Auth token. _Soon_.

Returns:  

  * `area_num`
  * `area_location`
  * `unit_list`
    * Array of unit id's
  * `area_id`

---

## Unit rental authorization

Method: `POST`  
Path: `/transaction/authorization`

Checks unit's status for rental/reserve transaction.  

Payload:

  * `unit_id`
  * `user_id`
  * Auth token. _Soon_.

Returns:

  * `activity_log_id`
  * `authorized`: boolean
  * `api_msg_code`: Only shows if there is a message
    * `1` - Locker unit is not available (_reserved_/_occupied_)
    * `2` - User is not authorized to rent/reserve (_User has existing rental/reserved unit_)



---

## Rental transaction

Method: `POST`  
Path: `/transaction/feed`

Updates server the user's transaction amount feed through coin feeder for rental transaction (_Rent/Extend_). 

Payload:

  * `auth_activity_log_id` (_Activity log ID of rental authorization_)
  * `transaction_amount`: Amount of the user feed into the coin slot
  * `transaction_type`: One of the f.f.
    * `Rent`
    * `Extend`
    * `Overdue`
  * `user_id`
  * Auth token. _Soon_.

Returns:  

  * `transaction_authorized`
  * `user_id`
  * `date`

---

## Acquire rental unit

Method: `POST`  
Path: `/transaction/acquire`

Confirms the acquire of a service by the user.

Payload:

  * `user_id`
  * `acquire_type`
  * `auth_activity_log_id`
    * Client must be authorized to rent the unit using `/auth`
  * Auth token. _Soon_.

Returns:  

  * `acquire_type`
    * `Rent`
    * `Extend`
    * `Reserve`
  * `user_id`